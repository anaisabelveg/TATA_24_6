# try-except-else-finally

numero = 0
try:
    # las sentencias que podrian provocar un error
    numero = int(input("Introduce numero entero: "))
except:
    # Este bloque se ejecuta si ha habido un error
    print("Error, debe ser un numero entero")
else:
    # Solo se ejecuta si no ha habido errores
    print("Correcto, has introducido un numero entero")
finally:
    # Siempre se ejecuta haya errores o no
    print("Numero:", numero)
    
# combinaciones minimas
try:
    pass
except:
    pass

try:
    pass
finally:
    pass

# try-else no funciona
''' 
try:
    pass
else:
    pass
'''