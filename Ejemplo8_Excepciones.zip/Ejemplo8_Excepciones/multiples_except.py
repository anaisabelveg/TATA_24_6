# Para poder mostrar la pila de llamadas necesitamos el modulo traceback
import traceback

try:
    # las sentencias que podrian provocar un error
    dividendo = int(input("Introduce dividendo: "))
    divisor = int(input("Introduce divisor: "))
    division = dividendo / divisor
except ValueError as error:
    # Este bloque se ejecuta si ha habido un error
    print("Error, debe ser un numero entero")
    print(error)
    print(type(error))
    traceback.print_exc()
except ZeroDivisionError as err:
    # Este bloque se ejecuta si ha habido un error
    print("Error, el divisor no puede ser 0")
    print(err)
except BaseException as e:
    # Este bloque se ejecuta si ha habido un error
    print("Error de otro tipo")
    print(e)
else:
    # Solo se ejecuta si no ha habido errores
    print("Resultado:", division)
finally:
    # Siempre se ejecuta haya errores o no
    print("----- FIN -----")
    
