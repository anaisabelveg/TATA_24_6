# Ejercicio 1
# crear una lista con las letras vocales
# utilizando compresion, crear un diccionario donde:
#   - la clave es el indice de la lista
#   - el valor es la letra
# { key:value .....   }
vocales = ['a','e','i','o','u']
resultado = {idx:vocales[idx]  for idx in range(len(vocales))}
print(resultado)


# Ejercicio 2
# Utilizando estas listas obtener un diccionario: lenguaje:version
lenguajes = ['Python', 'Java', 'PHP']
versiones = [3.12, 17, 8]
resultado = {lenguajes[idx]:versiones[idx] for idx in range(len(lenguajes)) }
resultado = dict( [(lenguajes[idx],versiones[idx]) for idx in range(len(lenguajes))]  )
print(resultado)

''' funcion zip  '''
lenguajes = ['Python', 'Java', 'PHP', 'JavaScript'] # si hay elementos sobrantes los ignora
versiones = [3.12, 17, 8]
resultado2 = {}
for lenguaje, version in zip(lenguajes, versiones):
    resultado2.update({lenguaje:version})
print(resultado2)

resultado3 = {lenguaje:version for lenguaje, version in zip(lenguajes, versiones)}
print(resultado3)

resultado4 = dict(zip(lenguajes, versiones))
print(resultado4)