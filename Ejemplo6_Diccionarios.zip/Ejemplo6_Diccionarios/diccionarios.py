# diccionarios: los elementos con key:value
# No tienen indices pero se accede a traves de la clave
# A partir 3.7 se garantiza el orden de entrada
# Las claves no se pueden repetir, se sobreescribe su valor
# Pero los valores si se pueden repetir
# Se crean con {}

alumnos = {'Juan': 6.4, "Maria": 8.3, "Luis": 6.4, "Adolfo": 7.1, "Maria": 9.3}
print(alumnos)
print(type(alumnos))  # <class 'dict'>

# Mostrar los nombres de los alumnos (claves)
print(alumnos.keys()) # dict_keys(['Juan', 'Maria', 'Luis', 'Adolfo'])

# Mostrar las notas de los alumnos (values)
print(alumnos.values()) # dict_values([6.4, 9.3, 6.4, 7.1])

# Mostrar los elementos que tengo en el diccionario
print(alumnos.items()) # dict_items([('Juan', 6.4), ('Maria', 9.3), ('Luis', 6.4), ('Adolfo', 7.1)])

# Accedemos a los elementos a traves de su clave
print("Nota de Luis:", alumnos['Luis'])
print("Nota de Luis:", alumnos.get('Luis'))

#print("Nota de Luis:", alumnos['Luissssss'])  # KeyError: 'Luissssss' si no lo encuentra
print("Nota de Luis:", alumnos.get('Luisssss'))  # None si no lo encuentra

# Operadores de pertenencia in y not in
print('Luisssss' in alumnos)
print('Luis' in alumnos)

print('Luisssss' not in alumnos)
print('Luis' not in alumnos)

# Borrar un elemento
#del alumnos['Adolfoooooo']  # KeyError: 'Adolfoooooo'
del alumnos['Adolfo']
#alumnos.__delitem__('Adolfo')   # Funciona tambien
#alumnos.__delitem__('Adolfoooooo') # KeyError: 'Adolfoooooo'
print(alumnos)

# Agregar nuevo elemento
alumnos['Pepito'] = 3.5
print(alumnos)

# Modificar la nota de Pepito
alumnos['Pepito'] = 5
print(alumnos)

# Eliminar el ultimo elemento
alumnos.popitem()
print(alumnos)

# Otra forma de agregar elementos al diccionario
alumnos.update({'Pepito': 5})
print(alumnos)

# Ordenar el diccionario
print("Orden ascendente:", sorted(alumnos.values()))
print("Orden ascendente:", sorted(alumnos))
print("Orden descendente:", sorted(alumnos, reverse=True))

# Recorrer un diccionario
for alum in alumnos:   # Solo me devuelve las claves
    print(alum, alumnos[alum]) 
    
for item in alumnos.items(): # cada item es una tupla
    print(item)
   
for nombre, nota in alumnos.items(): # cada item es una tupla
    print(nombre, "->", nota)
    
# eliminar todos los elementos
alumnos.clear()
print(alumnos)

# Otras formas de crear diccionarios
alumnos = dict()
alumnos = {}
alumnos = dict(Juan=6.4, Maria=8.3, Luis=6.4, Adolfo=7.1)
alumnos = dict([('Juan', 6.4), ("Maria", 8.3), ("Luis", 6.4), ("Adolfo", 7.1), ("Maria", 9.3)])    
print(alumnos)