""" 
    Solicitar 2 numeros al usuario
    Aplicar conversion
    Mostrar las operaciones aritmeticas
"""

n1 = float(input("Introduce un numero real (1.2): "))
n2 = float(input("Introduce otro numero real (1.2): "))
print("Suma:", round(n1 + n2, 2))
print("Resta:", round(n1 - n2,2))
print("Multiplicacion:", n1 * n2)
print("Division real:", n1 / n2)  # siempre devuelve el resultado como un numero real
print("Modulo o resto de la division:", n1 % n2)
print("Potencia:", n1 ** n2)
print("Division entera:", n1 // n2)