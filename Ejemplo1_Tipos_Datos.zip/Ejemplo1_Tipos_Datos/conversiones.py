import math

# Siempre que se introduce un valor por teclado, el interprete
# de Python lo considera un str
'''
num1 = input("Introduce un numero: ")
num2 = input("Introduce otro numero: ")
print(num1 + num2)  # concatena "82"
'''
# convertir un string a numero entero
# Todo lo que no sea un numero entero genera un ValueError
# ValueError: invalid literal for int() with base 10: 'ocho'
# ValueError: invalid literal for int() with base 10: '345ocho'
# ValueError: invalid literal for int() with base 10: '8.5678'
# ValueError: invalid literal for int() with base 10: 'True'
'''
numero1 = int(input("Introduce un numero entero: "))
numero2 = int(input("Introduce otro numero entero: "))
print(numero1 + numero2)
'''

# convertir un string a numero real
# La parte decimal con punto   76.34
# ValueError: could not convert string to float: 'abc'
# ValueError: could not convert string to float: '76,34'
# Los numeros enteros funciona sin problema
radio = float(input("Introduce radio del circulo: "))
#print("Area del circulo:", 3.1416 * radio * radio)
print("Area del circulo:", math.pi * radio ** 2)

# Redondear numeros round(que?, cuantos_decimales)
print("Area del circulo:", round(math.pi * radio ** 2, 2))

# convertir a texto
dato = 78
print(dato, type(str(dato)))

# convertir booleano a numericos
print(8 + False)  # conversion automatica False = 0  # resultado 8
print(8 + True)   # conversion automatica True = 1  # resultado 9
print(True + False)  # resultado 1