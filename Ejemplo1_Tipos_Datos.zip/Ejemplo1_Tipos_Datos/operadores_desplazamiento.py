''' Desplazamientos hacia la derecha '''
print(17 >> 1)   # 17 // 2 ** 1   ->    8
print(17 >> 2)   # 17 // 2 ** 2   ->    4
print(17 >> 3)   # 17 // 2 ** 3   ->    2
print(17 >> 4)   # 17 // 2 ** 4   ->    1
print(17 >> 5)   # 17 // 2 ** 5   ->    0
print(17 >> 6)   # 17 // 2 ** 6   ->    0

print(-17 >> 2)   # -17 // 2 ** 2   ->    -5
print(-17 >> 3)   # -17 // 2 ** 3   ->    -3

print(17 >> 0)   # 17 // 2 ** 0   ->    17
print(-17 >> 0)   # -17 // 2 ** 0   ->    -17

# El desplazamiento siempre tiene que ser positivo sino genera error
# ValueError: negative shift count
#print(17 >> -3)  

# Si el numero es 0, da igual desplazamiento izquierda o derecha, siempre sera 0
print(0 >> 2)   # 0 // 2 ** 2   ->    0

''' Desplazamientos hacia la izquierda '''
print(17 << 1)   # 17 * 2 ** 1   ->    34
print(17 << 2)   # 17 * 2 ** 2   ->    68
print(17 << 3)   # 17 * 2 ** 3   ->    136
print(17 << 4)   # 17 * 2 ** 4   ->    272
print(17 << 5)   # 17 * 2 ** 5   ->    544
print(17 << 6)   # 17 * 2 ** 6   ->    1088
print(17 << 7)   # 17 * 2 ** 7   ->    2176

print(-17 << 2)   # -17 * 2 ** 2   ->    -68
print(-17 << 3)   # -17 * 2 ** 3   ->    -136

print(17 << 0)   # 17 * 2 ** 0   ->    17
print(-17 << 0)   # -17 * 2 ** 0   ->    -17

# El desplazamiento siempre tiene que ser positivo sino genera error
# ValueError: negative shift count
#print(17 << -3) 

print(0 << 2)   # 0 * 2 ** 2   ->    0