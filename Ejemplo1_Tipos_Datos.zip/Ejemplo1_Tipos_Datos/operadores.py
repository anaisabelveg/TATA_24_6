# Operadores aritmeticos (+, -, *, /, %, **, //)
n1 = 9
n2 = 2
print("Suma:", n1 + n2)
print("Resta:", n1 - n2)
print("Multiplicacion:", n1 * n2)
print("Division real:", n1 / n2)  # siempre devuelve el resultado como un numero real
print("Division real:", 6 / 3)  # 2.0
print("Modulo o resto de la division:", n1 % n2)
print("Potencia:", n1 ** n2)
print("Division entera:", n1 // n2)

# Operadores de asignacion (+=, -=, *=, /=, %=, **=, //=)
#n1 = n1 + 3
n1 += 3
print(n1)
n1 -= 3  # n1 = n1 - 3
print(n1)
n1 *= 3  # n1 = n1 * 3
print(n1)
n1 /= 3  # n1 = n1 / 3
print(n1)
n1 %= 3  # n1 = n1 % 3   0.0
print(n1)
n2 **= 3  # n2 = n2 ** 3
print(n2)
n2 //= 3  # n2 = n2 // 3
print(n2)

# En Python no existen los incrementos o decrementos
# n1++
# ++n1
# n1--
# --n1

# Operadores relacionales (>, <, >=, <=, ==, !=)
# Retornan un valor booleano: True o False
n1 = 9
n2 = 2
print("El numero 1 es mayor que numero 2?", n1 > n2)
print("El numero 1 es menor que numero 2?", n1 < n2)
print("El numero 1 es igual que numero 2?", n1 == n2)
print("El numero 1 es distinto que numero 2?", n1 != n2)

# Operadores logicos (and, or, not)
print("and:", (n1 > n2) and (n2 == 6))
print("or:", (n1 > n2) or (n2 == 6))
print("not:", not(n2 == 6))
print("not:", not(n1 > n2))

# Operadores de identidad (is, is not)
n1 = 9
n2 = 9.0
print("Es el mismo contenido?", n1 == n2)
print("Es el mismo objeto?", n1 is n2)

dato1 = "Hola"
dato2 = "Hola"
print("---Es el mismo contenido?", dato1 == dato2)
print("---Es el mismo objeto?", dato1 is dato2)

nombres1 = ['Juan', 'Maria']
nombres2 = ['Juan', 'Maria']
print("Es el mismo contenido?", nombres1 == nombres2) # True, las listas son iguales
print("Es el mismo objeto?", nombres1 is nombres2) # False, las variables contienes referencias distintas

# Operadores de pertenecia (in, not in)
print('Luis' in nombres1)
print('Luis' not in nombres1)
print('Juan' in nombres1)
print('Juan' not in nombres1)