"""
    Comentarios en bloques: en python se llaman Docstrings
    pueden ser con comillas dobles o comillas simples
    Ejemplo de tipos de datos en Python
"""

# numeros enteros (int)
numero1 = 8
numero2 = 2
suma = numero1 + numero2
print(suma)
print("Resultado suma:", suma, "Tipo:", type(suma))

# numeros reales (float)
base = 5.78
altura = 9.23
area_triangulo = base * altura / 2
print("Area del triangulo:", area_triangulo, "Tipo:", type(area_triangulo))

# booleanos: True o False (bool)
soltero = True
print("Estas soltero?", soltero, "Tipo:", type(soltero))

# cadenas de texto (str)
# se puede utilizar comillas dobles o simples
nombre = "Pepito"
apellido = 'Perez'
edad = 27
print("Nombre completo:", nombre, apellido, "Tipo:", type(nombre), "Edad:", type(edad))

# Python solo permite concatenar datos de tipo str
print(nombre + " " + apellido)
# TypeError: can only concatenate str (not "int") to str
# print(nombre + " " + apellido + " " + edad)
# Solucion: los datos que no son de tipo str los convertimos a cadenas de texto
print(nombre + " " + apellido + " " + str(edad))

# Funcion print()
print()  # Deja una linea en blanco
print("Hola")
print("Hola", "Caracola")
# El separador por defecto es " " y el atributo end es el salto de linea
print("Hola", "Caracola", end=".") # hemos cambiado el salto de linea por un .
print("Hola", "Caracola", end=".\n")
print("Hola", "Caracola", end=".\n", sep="-")