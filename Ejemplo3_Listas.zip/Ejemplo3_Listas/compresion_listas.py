# Ejemplo 1
lista_palabras = ["casa", "mesa", "manzana", "pijama"]
longitud_palabras = []

for palabra in lista_palabras:
    longitud_palabras.append(len(palabra))
print(longitud_palabras)
    
''' compresion de lista '''
longitud_palabras2 = [len(palabra)  for palabra in lista_palabras ]    
print(longitud_palabras2)

# Ejemplo 2
num_pares = []

for num in range(0,15):
    if num % 2 == 0:
        if num < 7:
            num_pares.append(num) 
        else:
            num_pares.append(num + 1) 
print(num_pares)
        
''' compresion de lista '''
num_pares2 = [num if num < 7 else num+1  for num in range(0,15) if num % 2 == 0 ]
# num_pares2 = [num for num in range(0,15,2)]
print(num_pares2)