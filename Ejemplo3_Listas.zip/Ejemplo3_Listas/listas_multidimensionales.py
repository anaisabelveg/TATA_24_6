# lista de una dimension
lista = [1,2,3,4,5]  # un solo indice -> un bucle para recorrer

# listas de 2 dimensiones
matriz = [ [2,7,4], [8,1,6], [3,9,5] ]  # 2 indices (fila,columa)  -> 2 bucles

''' 
    2   7   4
    8   1   6 (1,2)
    3   9   5
'''

for fila in matriz:
    for num in fila:
        print(num, end="\t")
    else:
        print()
        
# Ejercicio
# Con la misma matriz sumar la diagonal principal  2+1+5
suma = 0
for idx_fila in range(len(matriz)) :
    for idx_col in range(len(matriz[idx_fila])):
        if idx_fila == idx_col:
            
            suma += matriz[idx_fila][idx_col]
else:
    print("Suma de la diagonal:", suma)
    

# Ejemplo de matriz no cuadrada, cada fila tiene diferente numero de columnas
matriz = [ [2,7,4,0], [8,1], [3,9,5,6,10,18] ]

# Cubo de rubbik -> matriz de 3 dimensiones
matriz = [[[2,7], [8,1], [3,9]], [[20,17], [82,11], [13,29]]]   # indices (x,y,z) -> 3 bucles