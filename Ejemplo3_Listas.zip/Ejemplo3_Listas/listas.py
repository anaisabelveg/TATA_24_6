# listas: colecciones ordenadas de elementos (tienen indice)
# en todas las colecciones podemos tener elementos de diferentes tipos
# permite tener elementos duplicados
# se crean con []

list1 = ['Maria', 'Perez', 30, 'soltera', 'sin hijos']
list2 = ['estudiante', 'medicina', 28010]

# tipo son las listas
print(type(list1))  # <class 'list'>

# mostrar las listas
print(list1)
print(list2)

# crear una lista vacia
lista_vacia = []
lista = list()

# unir listas (el orden es importante)
lista = list1 + list2
print(lista)
lista = list2 + list1
print(lista)

# longitud de la lista
print("Longitud de la lista:",len(lista))

# Acceso a los elementos de la lista
# Si el indice es positivo comenzamos por la izquierda
# Si el indice es negativo comenzamos por la derech2a
print("codigo postal:",lista[2])
print("estado civil:",lista[-2])
print("estado civil:",lista[len(lista) -2])  # lista[8-2] -> lista[6]

# Agregar elemento al final
lista.append("morena")
print(lista)

# Agregar elemento en una determinada posicion
lista.insert(0, 1.72)
print(lista)

# Agregar varios elementos a la vez al final
lista.extend([1,2,3])
print(lista)

# Eliminar un elemento de la lista
del lista[-1]
print(lista)

# Modificar un elemento de la lista
lista[-4] = '1 hijo'
print(lista)

# Recorrer la lista for in
for item in lista:
    print(item, end="-")
else:
    print("\n--------")


# Recorrer la lista for range
for indice in range(len(lista)):
    if (indice == len(lista) - 1):
        print(lista[indice])
    else:
        print(lista[indice], end="-")
else:
    print("-------")

# Recorrer la lista while
idx = 0
while(idx < len(lista)):
    print(lista[idx], end=" ")
    idx += 1
else:
    print("\n--------")
    
''' slices [begin:stop:step]  '''
# Mostrar todos los elementos de la lista
print("Todos:",lista[:])

# Mostrar los ultimos 4 elementos de la lista
print("Ultimos 4:",lista[-4:])

# Mostrar los elementos del indice 3 al 6 de la lista
print("Del 3 al 6:",lista[3:7])  # Recordar que al igual range el ultimo no esta incluido

# Mostrar los elementos del indice 6 al 3 de la lista
print("Del 6 al 3:",lista[6:2]) # sale vacio izda a dcha
print("Del 6 al 3:",lista[6:2:-1]) # sale vacio dcha a izda

# Mostrar desde el sexto a tercero pero empezando por la dcha, por el final
print("Del sexto al tercero:",lista[-6:-10:-1])
print("Del sexto al tercero:",lista[-6:2:-1])
print("Del sexto al tercero:",lista[6:2:-1])

# Mostrar todos los elementos en orden inverso
print("Todos inverso:",lista[::-1])

# Mostrar todos los elementos en orden inverso de 2 en 2
print("Todos inverso de 2 en 2:",lista[::-2])

# Mostrar todos los elementos de 2 en 2
print("Todos 2 en 2:",lista[0:len(lista):2])
print("Todos 2 en 2:",lista[::2])

''' Operadores de pertenencia: in y not in  '''
print("hola" in lista)
print("hola" not in lista)