# crear una lista llamada colores con los valores rojo, verde y azul
colores = ["rojo", "verde", "azul"]

# mostrar el tipo de la variable colores
print(type(colores))

# mostrar el contenido de la lista
print(colores)

# recorrer la lista con for in
for color in colores:
    print(color)

# recorrer la lista con for range
for idx in range(len(colores)) :
    print(colores[idx])

# mostrar el color verde (indice)
print(colores[1])

# borrar el color azul
del colores[2]
print(colores)

# crear una lista vacia mas_colores
mas_colores = []
mas_colores = list()

# en la nueva lista unir colores y otra lista con: blanco, negro, rosa, azul
mas_colores = colores + ["blanco", "negro", "rosa", "azul"]
print(mas_colores)

# añadir el color naranja al final
mas_colores.append("naranja")
print(mas_colores)

# añadir el color marron al principio
mas_colores.insert(0, "marron")
print(mas_colores)

# mostrar la longitud de la lista
print(len(mas_colores))

# mostrar el antepenultimo
print(mas_colores[-3])

''' slices  '''
# mostrar los 2 ultimos elementos
print(mas_colores[-2:])

# mostrar desde el ultimo al antepenultimo
print(mas_colores[-1:-4:-1])

# mostrar los 5 primeros
print(mas_colores[:5])

# mostrar del segundo al cuarto
print(mas_colores[1:4])

# mostrar del primero al penultimo de 2 en 2
print(mas_colores[:-1:2])

# mostrar del penultimo al primero de 2 en 2
print(mas_colores[-2::-2])

# Mostrar el indice donde esta el color azul
print(mas_colores.index("azul")) # 6
#print(mas_colores.index("amarillo"))  # ValueError: 'amarillo' is not in list
print(mas_colores.index("azul", 3))  # busca el color azul desde el indice 3

# Cuantos color azul tengo en mi lista
print(mas_colores.count("azul"))

# Invertir la lista
mas_colores.reverse()  # permanente
print(mas_colores)

# Ordenar la lista
mas_colores.sort()  # ascendente
print(mas_colores)

mas_colores.sort(reverse=True) # descendente
#mas_colores.reverse() 
print(mas_colores)

# eliminar todos los elementos de la lista
mas_colores.clear()
print(mas_colores)

