while True:
    pw = input()
    if pw == 'q':
        print('Ok: ', pw)
        break
        print("End")
    else:
        print('Wrong: ', pw)