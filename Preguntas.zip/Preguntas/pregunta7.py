#x = None  # nada o null
x = "None"  # texto
if x:  # comprobar si hay contenido en la variable x
    print("H")
else:
    print("G")