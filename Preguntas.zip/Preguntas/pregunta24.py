priority = float(input())
print(priority)
print("4.0 == 4?",priority == 4)
print("4.0 is 4?",priority is 4)

if (priority == 1):
   print ("FR")
elif (priority == 2):
   print ("GR")    
elif (priority == 3):
   print ("EN")
else:
   print("None")