for i in range(1):
    # sep="-" solo aplica si en el mismo print() muestras varias cosas
    #print("*", "ggg", end="", sep="-")
    print("*", end="", sep="-")
else:
    print("*")