data=""  # igual data=None
while data:
    print("Data is not empty")
else:
    print("Data is empty")