points = [65, 75, 90, 80, 80, 100, 100]
avg = sum (points) // len(points)
print (avg)   # avg es igual a 84.
if 91 <= avg <= 100:
   grade = 10
elif 81 <= avg < 90:
   grade = 9
elif 71 <= avg < 80:
   grade = 8
elif 81 <= avg < 70:
   grade = 7
elif 81 <= avg < 60:
   grade = 6
else:
   grade = 5
 
print (grade)