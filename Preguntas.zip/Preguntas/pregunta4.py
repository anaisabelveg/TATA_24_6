def test(text, x):
    # bucle infinito porque no se modifica la variable x
    while x >= 0:
        print(text, end=" ")
    x = x - 2
    
test('Procoding', 7)