# Ejercicio 1
# Dada la lista de numeros, crear una tupla con los cuadrados de cada numero
# (1,4,9,16,25)
numeros = [1,2,3,4,5]
#tupla_numeros = tuple([num ** 2  for num in numeros]  )
tupla_numeros = tuple(num ** 2  for num in numeros  )
print(tupla_numeros)

# De esta forma crea un generador y no una tupla 
generador = (num ** 2  for num in numeros  )
print("Generador:",generador) # Generador: <generator object <genexpr> at 0x101e3f920>
for dato in generador:
    print(dato, end=" ")
print()


# Ejercicio 2
# crear la tupla de 2 dimensiones por cada numero
# ((1,1),(2,4),(3,9),(4,16),(5,25))
# tupla de tuplas
tupla_cuadrados = tuple( (num, num ** 2)  for num in numeros)
print(tupla_cuadrados)

# tupla de listas
tupla_cuadrados = tuple( [num, num ** 2]  for num in numeros)
print(tupla_cuadrados)

# la tupla no se puede modificar pero las listas si
tupla_cuadrados[0][0] = 27
print(tupla_cuadrados)
