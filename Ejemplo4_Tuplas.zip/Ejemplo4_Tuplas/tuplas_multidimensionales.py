# crear una tupla de 2 dimensiones
personas = ( ('Juan', 27, 'Soltero'), ('Maria',), ('Luis', 43, 'Casado', '2 hijos') )

# Para recorrer la tupla de 2 dimensiones necesitamos 2 bucles
for persona in personas:
    #print(persona)
    for dato in persona:
        print(dato, end=" ")
    else:
        print()