# tuplas: Colecciones ordenadas (con indice) pero son inmutables
# no podemos agregar, eliminar, modificar datos de una tupla
# igual que las listas permite elementos duplicados
# igual que el resto de colecciones los datos pueden ser de diferente tipo
# se crean ()
# Ejemplos de uso: meses del año, dias de la semana, estados civil, puntos cardinales

# crear una tupla con los dias de la semana
dias = ('lunes', 'martes', 'miercoles', 'jueves', 'viernes', 'sabado', 'domingo')
print(dias)
print(type(dias))  # <class 'tuple'>

# crear una tupla vacia
tupla_vacia = ()
tupla_vacia = tuple()

# Recorrer una tupla con for in
for dia in dias:
    print(dia, end=" ")
print()

# Recorrer la tupla for range
for idx in range(len(dias)) :
    print(dias[idx], end=" ")
print()

# Mostrar el jueves
print(dias[3])

''' errores  '''
#del dias[0]  # TypeError: 'tuple' object doesn't support item deletion
#dias.append('otro sabado')  # AttributeError: 'tuple' object has no attribute 'append'
#dias[0] = 'otro viernes'  # TypeError: 'tuple' object does not support item assignment

# longitud de la tupla
print(len(dias))

# Cuantos lunes hay en la tupla
print(dias.count("lunes"))

# En que posicion esta el viernes
print(dias.index("viernes"))  # retorna solo el primer viernes encontrado
print(dias.index("viernes", 2)) # retorna el viernes encontrado a partir del indice 2
# ValueError: tuple.index(x): x not in tuple
#print(dias.index("viernes", 6))

'''  concatenar tuplas   '''
# TypeError: can only concatenate tuple (not "str") to tuple
#otra_tupla = dias + ('otro sabado')

# TypeError: can only concatenate tuple (not "int") to tuple
#otra_tupla = dias + (1)

# Es necesario poner la , para que lo reconozca como tupla
otra_tupla = dias + ('otro sabado',)
print(otra_tupla)

# El orden es importante
otra_tupla =  ('otro sabado',) + dias
print(otra_tupla)

# TypeError: can only concatenate tuple (not "list") to tuple
#otra_tupla = dias + ['otro_sabado','otro_domingo']
#otra_tupla = dias + (['otro_sabado','otro_domingo'])

# Hay que crear la tupla con el contructor de tuple()
otra_tupla = dias + tuple(['otro_sabado','otro_domingo'])
print(otra_tupla)

# Convertir la tupla en lista
print(list(otra_tupla))

''' slices [begin:stop:step] '''
# mostrar los datos de martes a jueves
print(dias[1:4])  # el ultimo no se incluye

# mostrar los dias de la semana en orden invero
print(dias[::-1])

# Otra forma de crear tuplas
numeros = 1,2,3,4,5
print(numeros) 
print(type(numeros)) # <class 'tuple'>

# Multiplicar listas
resultado = [1,2,3] * 2
print(resultado)

# Multiplicar tuplas
letras = ('a','e','i','o','u') * 3
print(letras)

# Multiplicar texto
separador = "-" * 30
print(separador)

#"lunes".upper()
#"lunes".lower()

