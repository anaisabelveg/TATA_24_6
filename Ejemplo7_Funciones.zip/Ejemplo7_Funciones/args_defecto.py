# En esta funcion el parametro nombre es obligatorio
# pero el estado civil es optativo
# puedo llamar a esta funcion pasando el estado civil o no
# si no lo paso, cogera el valor por defecto (Soltero)

# SyntaxError: parameter without a default follows parameter with a default
#def datos_trabajador( estado_civil="Soltero", nombre):  

# Los parametros obligatorios tienen que ir al principio  
def datos_trabajador( nombre, estado_civil="Soltero", sueldo=21000): 
    return nombre + " esta " + estado_civil + " gana " + str(sueldo)

print(datos_trabajador(nombre="Juan"))
print(datos_trabajador(nombre="Jorge", estado_civil="Casado"))
print(datos_trabajador("Maria", "Divorciada", 38000))

# TypeError: can only concatenate str (not "int") to str
# Porque esta interpretando que 42000 es el estado civil
#print(datos_trabajador("Elena", 42000))
print(datos_trabajador("Elena", sueldo=42000))


# Ejercicio
# Crear un funcion que recibe:
#   - datos (texto) como numero variable de argumento
#   - caracter opcional que actue como separador
def unir_datos( *datos, separador=" "):
    cadena = ""
    for dato in datos:
        cadena += dato + separador
    return cadena
    
    #return separador.join(datos)

print(unir_datos('a','e','i','o','u')) 
print(unir_datos('a','e','i','o','u', "-"))  # coge el - como un dato mas

# Si hay numero variable de argumentos hay que poner el keywords separador
print(unir_datos('a','e','i','o','u', separador="-"))
print(unir_datos('a','e','i','o','u', separador=" | "))
print(unir_datos('a','e','i','o','u', separador=" - "))

# Probar a intercambiar el orden de los argumentos en la funcion
# SyntaxError: positional argument follows keyword argument
#print(unir_datos(separador="-", 'a','e','i','o','u'))