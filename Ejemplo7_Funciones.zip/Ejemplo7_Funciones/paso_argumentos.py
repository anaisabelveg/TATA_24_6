# nombre se considera una variable local y solo existe dentro de la funcion
# print(nombre) da error porque no lo reconoce como variable
def detalle(nombre, apellido, edad, altura):  
    nombre = "Alvaro"
    print("Nombre completo:",nombre,apellido)
    print("Edad:",edad)
    print("Altura:",altura)
    
# Invocar a la funcion pasando los argumentos por posicion
detalle("Pepito", "Perez", 35, 1.84)

# Invocar a la funcion utilizando los nombres de los parametros
# se llama los keywords
detalle(nombre="Pepito", apellido="Perez", edad=35, altura=1.84)

# Si utilizamos keywords no es necesario respetar el orden 
detalle(altura=1.84, apellido="Perez", edad=35,nombre="Pepito" )

# variable global, es cuando se declara fuera de uhna funcion, condicional, bucle
# No esta en ningun bloque de codigo
# Puedo utilizar esta variable en todo el codigo.py
nombre = "Juanito"
detalle(nombre, "Perez", 35, 1.84)
# print(nombre)

x = "dato 1"  # variable global
print(x)

def prueba():
    global x   # si quieres modificar la variable x global
    x= "dato 2"   # crear una variable local
    print("----",x)  # busca la variable x mas cercana
    
prueba()
print("******",x)  # dato 1