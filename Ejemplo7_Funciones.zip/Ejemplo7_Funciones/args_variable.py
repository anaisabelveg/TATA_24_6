# declarar una funcion con numero variable de argumentos
def sumar(*numeros):
    #print(type(numeros))  # <class 'tuple'>
    #suma # UnboundLocalError: cannot access local variable 'suma' where it is not associated with a value
    suma = 0
    for num in numeros:
        suma += num
    return suma
    
print("Suma:",sumar())
print("Suma:",sumar(7))
print("Suma:",sumar(7,5))
print("Suma:",sumar(7,5,1))
print("Suma:",sumar(7,5,1,6))

# print("Suma:",sumar("a", "e", "i", "o", "u"))

# Ejercicio
# Crear una funcion que recibe el nombre del alumno  y las notas de las asignaturas matriculadas
# retornar el nombre y la media de las notas como un texto
# en el caso de tener varios parametros, si un es variable debe ir al final
def calcular_media(nombre, *notas):
    if len(notas) > 0:
        nota_media = sum(notas) / len(notas)
    else:
        nota_media = 0
    return "Nombre: " + nombre + " Nota media: " + str(nota_media)

print(calcular_media("Jorge"))  # ZeroDivisionError: division by zero
print(calcular_media("Juan", 0))
print(calcular_media("Alvaro", 5, 8, 6))
print(calcular_media("Maria", 9, 10, 8.5, 9.75))