# declarar funciones
def saludar():   # funcion sin parametros y sin retorno
    # cuerpo de la funcion
    print("Hola, que tal?")
    
def despedir(nombre):  # funcion recibe como parametro el nombre y retorna un mensaje personalizado
    return nombre + ", Hasta luego"
    
    
# invocar o llamar a la funcion
saludar()  # obligatorio poner los parentesis
mensaje = despedir("Pepito")
print(mensaje)
print(despedir("Juanito"))

# si llamo a la funcion sin parentesis
saludar  # No da error pero no hace nada porque no lo reconoce como funcion

# si llamo a una funcion sin parametros y le paso un valor
#saludar("Miguelito") # TypeError: saludar() takes 0 positional arguments but 1 was given

# Si llamo a una funcion con parametros y no le paso ninguno
# print(despedir()) # TypeError: despedir() missing 1 required positional argument: 'nombre'
