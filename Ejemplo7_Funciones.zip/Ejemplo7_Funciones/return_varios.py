'''  
    Crear una funcion que recibe un texto y retornar
        - Texto en mayusculas   text.upper()
        - Texto en minusculas   text.lower()
        - Longitud del texto
'''

def procesar_texto(texto):
    return texto.upper(), texto.lower(), len(texto)

# Recuperar el valor con multiples variables
mayusculas, minusculas, longitud = procesar_texto("Por fin es viernes")
print(mayusculas)
print(minusculas)
print(longitud)

# Recuperar como una tupla
tupla = procesar_texto("Por fin es viernes")
print(tupla)
for item in tupla:
    print(item)
    
# Recuperar el valor con 2 variables
# ValueError: too many values to unpack (expected 2)
mayusculas, minusculas = procesar_texto("Por fin es viernes")
print(mayusculas)
print(minusculas)
