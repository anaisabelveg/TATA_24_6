""" 
    Solicitar al usuario una letra del dia de la semana (l,m,x,j,v,s,d)
    puede ser que escriba la letra en minusculas o mayusculas
    mostrar el dia de la semana
    si no es letra valida -> Dia no valido
"""
letra = input("Introduce dia de la semana (l,m,x,j,v,s,d): ")

match letra :
    case 'l' | 'L':
        print("Es lunes")
    case 'm' | 'M':  
        print("Es martes")
    case 'x' | 'X':  
        print("Es miercoles") 
    case 'j' | 'J':
        print("Es jueves")
    case 'v' | 'V': 
        print("Es viernes")
    case 's' | 'S': 
        print("Es sabado")
    case 'd' | 'D': 
        print("Es domingo")
    case _:
        print("Dia no valido")   
        