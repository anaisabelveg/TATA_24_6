# Crear una lista [] de nombres
nombres = ['Luis', 'Jorge', 'Maria', 'Laura', 'Pedro']
print("longitud", len(nombres))  # el numero de elementos de la lista


# por cada elemento que tenemos en la lista nombres:
#   lo mostramos en la terminal
for elemento in nombres:
    print(elemento, end=" ")
else:
    # se ejecuta una sola vez al final del bucle
    print("\n----------- FIN ---------")
    
''' rangos '''
# Mostrar los numeros del 0 al 9
for numero in range(10):  # Rango van del 0 al numero-1
    print(numero, end=" ")
else:
    print("\n----------- FIN ---------")
    
# Mostrar los numeros del 1 al 10
for numero in range(1, 11):  # Rango va del 1 al numero-1
    print(numero, end=" ")
else:
    print("\n----------- FIN ---------")
    
# Mostrar los numeros del 0 al 10 de 2 en 2
for numero in range(0, 11, 2):  
    print(numero, end=" ")
else:
    print("\n----------- FIN ---------")
    
# Mostrar los numeros del 10 al 1
for numero in range(10, 0, -1):  
    print(numero, end=" ")
else:
    print("\n----------- FIN ---------")
    
# Mostrar los numeros desde -10 hasta -100 de 10 en 10
for numero in range(-10, -101, -10):  
    print(numero, end=" ")
else:
    print("\n----------- FIN ---------")