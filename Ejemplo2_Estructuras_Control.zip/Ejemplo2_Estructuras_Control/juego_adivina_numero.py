'''  
    Generar un numero aleatorio del 0 al 10
    solicitar numero al usuario hasta que lo adivine
    le vamos dando pistas: te has pasado, te has quedado corto
'''

import random

num_aleatorio = random.randint(0,10)
print(num_aleatorio)
numero = -1
while ( numero != num_aleatorio):
    numero = int(input("Adivina numero: "))
    if numero > num_aleatorio:
        print("Te has pasado, prueba con un numero menor")
    elif numero < num_aleatorio:
        print("Te has quedado corto, prueba con un numero mayor")
else:
    print("Has acertado")
    

