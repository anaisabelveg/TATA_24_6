'''  
    Mostrar los numeros primos del 1 al 100
    un numero primo solo es divisible por si mismo y la unidad
    para probar si 7 es primo, recorremos sus posible divisores del 2 al 6
'''

# Version 1
for numero in range(1, 101):
    # Todos los numeros son primos salvo que se demuestre lo contrario
    es_primo = True
    print("Probando numero", numero)
    
    for divisor in range(2, numero):
        print("Probando divisor", divisor)
        if numero % divisor == 0:
            es_primo = False
            break   # Damos por terminado el bucle de divisores
            
    # Al terminar de comprobar todos los divisores si sigue siendo primo lo muestro
    if es_primo:
        print(numero, end=" ")
  
      
# Version 2
for numero in range(1, 101):
    for divisor in range(2, numero):
        if numero % divisor == 0:
            break
    else:
        print(numero, end=" ")
 
       
for numero in range(0, 10):
    break
    # si hay un break no se ejecuta el bloque else 
else:
    print(numero)
    
    
# Ejemplo con continue
for numero in range(1, 101):
    # Contador para llevar la cuenta de los divisores de ese numero
    contador = 0
    
    for divisor in range(2, numero):
        if numero % divisor == 0:
            contador += 1
    
    if contador > 0:
        continue
    print(numero, end=" ")