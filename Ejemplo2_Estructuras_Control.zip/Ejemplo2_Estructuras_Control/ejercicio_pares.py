"""  
    Recorrer la lista de numeros
    y mostrar en la terminal solo los numeros pares
"""
numeros = [4,8,1,9,2,11,15,3,7,18,5,0,21,44,57,91,82,39,43,100]
for num in numeros :
    if num % 2 == 0:
        print(num, end=" ")
        
"""  
    Con la lista de numeros anterior
    mostrar la suma de todos los elementos
"""
suma = 0
for num in numeros :
    suma += num   # suma = suma + num
else:
    print("Suma:", suma)