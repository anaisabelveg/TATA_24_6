# condicional mas simple
# si se cumple la condicion :
#   se ejecuta este bloque
hora = 9
if hora == 14 :
    print("La clase ha terminado")
    

# condicional con alternativa
# si se cumple la condicion :
#   se ejecuta este bloque
# si no se cumple :
#   se ejecuta este otro bloque
if hora == 14 :
    print("La clase ha terminado")
else :
    print("Lo siento, todavia estamos en clase")
    

# condicional anidado
# si se cumple la condicion :
#   se ejecuta este bloque
# si no se cumple probamos con otra condicion y si se cumple:
#   se ejecuta este otro bloque
# si no se cumple ninguna de las condiciones anteriores:
#   se ejecuta este ultimo bloque
n1 = 20
n2 = 15
if n1 > n2 :
    print("El numero", n1, "es el mayor")
elif n1 < n2 :
    print("El numero", n2, "es el mayor")
else:
    print("Los numeros son iguales")