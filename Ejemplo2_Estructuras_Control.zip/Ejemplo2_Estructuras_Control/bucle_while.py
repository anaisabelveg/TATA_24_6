''' En Python no existe el bucle do while  '''
# Mostrar los numeros del 1 al 10
num = 1
while num <= 10:
    print(num, end=" ")
    num += 1
else:
    print("\n------ FIN ------")
    
'''  
    Solicitar una contraseña al usuario 
    hasta que adivine que es "curso"
'''
pw = ""
while pw != "curso":
    pw = input("Introduce PW: ")
else:
    print("PW correcto")