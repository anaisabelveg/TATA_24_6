# Ejercicio 1
# Crear un conjunto como resultado con las letras de la palabra 'abracadabra'
# que no sean a, ni b, ni c

# Solucion con compresion
conjunto_letras = {letra  for letra in 'abracadabra' if letra not in {'a','b','c'} }
print(conjunto_letras)
print(type(conjunto_letras))

# Solucion con operaciones de conjuntos
#palabra = {'a','b','r','a','c','a','d','a','b','r','a'}
palabra = set('abracadabra')
eliminar = {'a','b','c'}
print(palabra.difference(eliminar)) # {'r', 'd'}

print(palabra - eliminar)

print(palabra.symmetric_difference(eliminar)) # {'r', 'd'}