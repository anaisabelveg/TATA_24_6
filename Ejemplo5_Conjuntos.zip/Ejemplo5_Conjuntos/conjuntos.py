# conjuntos: colecciones sin orden (no usamos indices)
# No permite elementos duplicados, los ignora
# No se garantiza el orden de entrada de los elementos
# Como en todas las colecciones, elementos de diferente tipo
# Se crean utilizando {}
# conjunto = {} python lo interpreta como diccionario

frutas = {'manzana', 'naranja', 'pera', 'naranja', 'platano'}
print(frutas)
print(type(frutas)) # <class 'set'>

# crear un conjunto vacio
conjunto_vacio = {}
print(type(conjunto_vacio))  # <class 'dict'>

conjunto_vacio = set()
print(type(conjunto_vacio))  # <class 'set'>

# agregar elementos
frutas.add('fresas')
print(frutas)

# eliminar elementos
# del borra por indice
frutas.remove("platano")
print(frutas)

# longitud del conjunto
print(len(frutas))

# Copiar este conjunto en otro
otro = frutas.copy()
print(otro)

# concatenar conjuntos
# TypeError: unsupported operand type(s) for +: 'set' and 'set'
#resultado = frutas + {'melon', 'sandia'}
resultado = frutas.union({'melon', 'sandia'})
print(resultado)

# Recorrer conjuntos
for fruta in frutas:
    print(fruta, end=" ")
print()

# Convertir el conjunto a tupla
tupla = tuple(frutas)
print(tupla)  # ('pera', 'manzana', 'naranja', 'fresas')

# Convertir el conjunto a lista
lista = list(frutas)
print(lista)  # ['manzana', 'pera', 'fresas', 'naranja']

# Operadores de pertenencia in y not in
print("maracuya" in frutas)
print("maracuya" not in frutas)
print("fresas" in frutas)
print("fresas" not in frutas)

# eliminar todos los elementos del conjunto
frutas.clear()
print(frutas)